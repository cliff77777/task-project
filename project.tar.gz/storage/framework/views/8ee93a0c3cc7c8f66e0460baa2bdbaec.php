

<?php $__env->startSection('content'); ?>
    
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <h1 class="my-4">編輯任務流程</h1>
        <form action="<?php echo e(route('task_flow.update', $template['id'])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('update'); ?>
            <div class="row">
                <div class="mb-3 col-md-6">
                    <label for="task_flow_name" class="form-label">流程名稱</label>
                    <input type="text" class="form-control" id="task_flow_name" name="task_flow_name" required
                        value="<?php echo e($template['task_flow_name']); ?>">
                </div>
            </div>
            <div class="mb-3">
                <label for="task_flow_step" class="form-label">流程步驟</label>
                <div id="formContainer">
                    <?php $__currentLoopData = $template->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row align-items-center mb-3">
                            <!-- 第一個欄位 -->
                            <div class="col-md-1 align-items-center">
                                step.<?php echo e($step->order); ?>

                                <input class="step" type='hidden' value="<?php echo e($step['order']); ?>"
                                    name="step[<?php echo e($step->order); ?>]">
                            </div>
                            <div class="col-md-2">
                                <label for="sendEmailNotification" class="form-label">是否寄送郵件通知</label>
                                <div class="row">
                                    <div class="form-check col-md-6">
                                        <input class="form-check-input" type="radio"
                                            name="step[<?php echo e($step['order']); ?>][sendEmailNotification]"
                                            id="sendEmailNotificationOn_<?php echo e($step['order']); ?>"
                                            <?php echo e($step['sendEmailNotification'] == 1 ? 'checked' : 'false'); ?> value="1">
                                        <label class="form-check-label" for="sendEmailNotificationOn">On</label>
                                    </div>
                                    <div class="form-check col-md-6">
                                        <input class="form-check-input" type="radio"
                                            name="step[<?php echo e($step['order']); ?>][sendEmailNotification]"
                                            id="sendEmailNotificationOff_<?php echo e($step['order']); ?>" value="0"
                                            <?php echo e($step['sendEmailNotification'] == 0 ? 'checked' : 'flase'); ?>>
                                        <label class="form-check-label" for="sendEmailNotificationOff">Off</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label for="[<?php echo e($step['order']); ?>][to_role]" class="form-label">執行權限</label>
                                <select class="form-select" id="[1][to_role]" name="step[<?php echo e($step['order']); ?>][to_role]"
                                    required>
                                    <?php $__currentLoopData = $user_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        {
                                        <option value="<?php echo e($role->id); ?>"
                                            <?php echo e($step['to_role'] == $role->id ? 'selected' : ''); ?>><?php echo e($role['role_name']); ?>

                                        </option>
                                        }
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label for="[1][descript]" class="form-label">職責說明</label>
                                <input type="text" name="step[1][descript]" class='form-control'
                                    <?php echo e($step['order'] == 1 ? 'readonly' : ''); ?> value="<?php echo e($step['descript']); ?>">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
        </form>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/task_flow/edit.blade.php ENDPATH**/ ?>