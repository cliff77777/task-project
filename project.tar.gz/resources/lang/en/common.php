<?php
return [
    'welcome' => 'Welcome to our website!',
    'about' => 'About Us',
    'contact' => 'Contact Us',
];


?>