

<?php $__env->startSection('content'); ?>
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <h1 class="my-4">工作單詳情</h1>
        <div class="mb-4">
            <h4>
                <p><strong>主旨:</strong><?php echo e($task->subject); ?></p>
            </h4>
            <p><strong>預計工時:</strong> <?php echo e($task->estimated_hours); ?> 小時</p>
            <p><strong>創建人:</strong> <?php echo e($task->creator->name); ?></p>
            <p><strong>指派給:</strong> <?php echo e($task->assignee->name ?? '未指派'); ?></p>
            <p><strong>工作敘述:</strong></p>
            <p>
                <textarea class="form-control" readonly><?php echo e($task->description); ?></textarea>
            <p>
        </div>
        
        <div class="mb-4">
            <h3 class="mb-4">任務作業</h3>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php $__currentLoopData = $task_note; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($task_note) > $note['step']): ?>
                    <form action="<?php echo e(route('update_task_note')); ?>" method="POST">
                    <?php else: ?>
                        <form action="<?php echo e(route('update_task_note_final')); ?>" method="POST">
                <?php endif; ?>

                <?php echo csrf_field(); ?>
                
                <h4>Step<?php echo e($note['step']); ?>.<?php echo e($note->task_flow_step['descript']); ?></h4>
                <div class="mb-3">
                    <label for="note" class="form-label">工作備註</label>
                    <textarea class="form-control" id="note" name="note" required>
                            <?php echo e(old('note', $note['note'])); ?>

                        </textarea>
                </div>
                <div class="mb-3">
                    <label for="actual_hours" class="form-label">實際工時</label>
                    <input type="number" step="0.1" class="form-control" id="actual_hours" name="actual_hours"
                        value="<?php echo e(old('actual_hours', $note['actual_hours'])); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="actual_hours" class="form-label">工作狀態</label>
                    <select class="form-control" name="status" id="status" required>
                        <option value="">--please select--</option>
                        <option value="0" <?php echo e($note['status'] == '0' ? 'selected' : ''); ?>>未完成</option>
                        <option value="1" <?php echo e($note['status'] == '1' ? 'selected' : ''); ?>>完成</option>
                    </select>
                    <input type="text" name="note_id" hidden value="<?php echo e($note['id']); ?>">
                    <input type="text" name="task_id" hidden value="<?php echo e($note['task_id']); ?>">
                    <input type="text" name="step" hidden value="<?php echo e($note['step']); ?>">

                </div>
                
                <?php if(count($task_note) > $note['step']): ?>
                    <div class="mb-3">
                        <label for="assign_next" class="form-label">指派下一位</label>
                        <select class="mb-3 form-control" name="assign_next" id="assign_next">
                            <?php $__currentLoopData = $task_note[$key + 1]->task_flow_step->role_to_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user['id']); ?>"><?php echo e($user['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                <?php endif; ?>
                
                <?php if($auth == $note['assign_to'] && $get_task_next_step['step'] == $note['step'] && $get_task_next_step['status'] == 0): ?>
                    <button type="submit" class="btn btn-primary mb-3">流程處理</button>
                <?php elseif($auth == $note['assign_to'] && $get_task_next_step['step'] == $note['step']): ?>
                    <div class="text-danger mb-3">程序處理中</div>
                <?php endif; ?>

                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        

        <div class="mb-4">
            <h4>上傳文件</h4>
            <form action="<?php echo e(route('upload_file', $task->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="file" class="form-label">選擇文件</label>
                    <input type="file" class="form-control" id="file" name="file" required>
                </div>
                <button type="submit" class="btn btn-primary">上傳</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/tasks/show.blade.php ENDPATH**/ ?>