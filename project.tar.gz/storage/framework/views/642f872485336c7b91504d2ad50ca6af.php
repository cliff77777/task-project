
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('layouts.sidebarMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-8">
                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <h1 class="my-4">新增工作單</h1>
                    <form action= method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="subject" class="form-label">主旨</label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">工作內容說明</label>
                            <textarea class="form-control" id="description" name="description" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="estimated_hours" class="form-label">預計工時</label>
                            <input type="number" step="0.1" class="form-control" id="estimated_hours"
                                name="estimated_hours" required>
                        </div>
                        <button type="submit" class="btn btn-primary">提交</button>
                    </form>
                </main>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/issuepage/index.blade.php ENDPATH**/ ?>