

<?php $__env->startSection('content'); ?>
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4 ">
        <h1 class="my-4">流程詳情</h1>
        <div class="mb-4">
            <div class="mb-2">
                <label for="task_flow_name" class="form-label">
                    <h4>流程名稱:</h4>
                </label>
                <input type="text" class="form-control w-25" value="<?php echo e($template->task_flow_name); ?>" readonly>
            </div>

            <div class="mb-2">
                <label for="task_flow_name" class="form-label">
                    <h4>創建人:</h4>
                </label>
                <input type="text" class="form-control w-25" value="<?php echo e($template->creator->name); ?>" readonly>
            </div>

            <div class="mb-2">
                <label for="task_flow_name" class="form-label">
                    <h4>最後更新人:</h4>
                </label>
                <input type="text" class="form-control w-25" value="<?php echo e($template->updater->name); ?>" readonly>
            </div>

            <h4>
                <p><strong>步驟詳情 </strong></p>
            </h4>
            <?php $__currentLoopData = $template->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion" id="accordionPanelsStayOpenstep" style="max-width: 18rem;">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="panelsStayOpen-headingOne<?php echo e($step->order); ?>">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                data-bs-target="#panelsStayOpen-collapseOne<?php echo e($step->order); ?>" aria-expanded="true"
                                aria-controls="panelsStayOpen-collapseOne">
                                步驟<?php echo e($step->order); ?>

                            </button>
                        </h2>
                        <div id="panelsStayOpen-collapseOne<?php echo e($step->order); ?>" class="accordion-collapse collapse show"
                            aria-labelledby="panelsStayOpen-headingOne<?php echo e($step->order); ?>">
                            <div class="accordion-body">
                                <p><strong>需求權限:<?php echo e($step->role_name); ?></strong></p>
                                <p><strong>信箱驗證信:<font
                                            class="<?php echo e($step->sendEmailNotification == 1 ? 'text-success' : 'text-danger'); ?>">
                                            <?php echo e($step->sendEmailNotification == 1 ? 'ON' : 'OFF'); ?></font>
                                    </strong></p>
                                <p><strong>步驟描述:<?php echo e($step->descript); ?></strong></p>
                                <p><strong>流程創建時間: <?php echo e($step->created_at); ?></strong></p>
                            </div>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/task_flow/show.blade.php ENDPATH**/ ?>