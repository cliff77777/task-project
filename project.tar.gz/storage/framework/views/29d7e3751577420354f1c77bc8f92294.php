
<?php $__env->startSection('content'); ?>
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">

        <h1>Activity Log</h1>
        <table class='table table-striped'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Description</th>
                    <th>Subject Type</th>
                    <th>Subject ID</th>
                    <th>Causer Type</th>
                    <th>Causer ID</th>
                    <th>User Name</th>
                    <th>Properties</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($activity->id); ?></td>
                        <td><?php echo e($activity->description); ?></td>
                        <td><?php echo e($activity->subject_type); ?></td>
                        <td><?php echo e($activity->subject_id); ?></td>
                        <td><?php echo e($activity->causer_type); ?></td>
                        <td><?php echo e($activity->causer_id); ?></td>
                        <td><?php echo e($activity->user->name); ?></td>
                        <td><?php echo e(json_encode($activity->properties)); ?></td>
                        <td><?php echo e($activity->created_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div>
            <?php if($activities->onFirstPage()): ?>
                <!-- 如果在第一頁，不顯示上一頁按鈕 -->
            <?php else: ?>
                <a href="<?php echo e($activities->previousPageUrl()); ?>" class="btn btn-primary">上一頁</a>
            <?php endif; ?>

            <?php if($activities->hasMorePages()): ?>
                <a href="<?php echo e($activities->nextPageUrl()); ?>" class="btn btn-primary">下一頁</a>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/activity_log/index.blade.php ENDPATH**/ ?>