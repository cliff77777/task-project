

<?php $__env->startSection('content'); ?>
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="container mt-5">
            <?php if(session('success')): ?>
                <div id="successAlert" class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div id="errorAlert" class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
        </div>

        <h1 class="my-4">流程列表</h1>
        <div class="mb-4">
            <a href="<?php echo e(route('task_flow.create')); ?>" class="btn btn-primary">新增任務流程</a>
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>流程名稱</th>
                    <th>創建人</th>
                    <th>流程步驟</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $task_flow_template; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($template->task_flow_name); ?></td>
                        <td><?php echo e($template->creator->name); ?></td>
                        <td><?php echo e($template->steps_count); ?></td>
                        <td>
                            <a href="<?php echo e(route('task_flow.show', $template->id)); ?>" class="btn btn-sm btn-info">詳細內容</a>
                            
                            
                            <a onclick="confirmCancel(event, '<?php echo e(route('task_flow.destroy', $template->id)); ?>', <?php echo e($template->id); ?>)"
                                class="btn btn-sm btn-danger">刪除流程
                            </a>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($task_flow_template->links()); ?>

    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script>
            function confirmCancel(event, url, template_id) {
                event.preventDefault();
                var confirmAction = confirm("Are you sure you want to delete this task flow?");
                if (confirmAction) {
                    console.log(template_id);
                    $.ajax({
                        url: url,
                        type: 'DELETE',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',
                            'id': template_id
                        },
                        success: function(response) {
                            alert(response.message);
                            location.reload()
                        },
                        error: function(xhr) {
                            alert(xhr.message);
                        }
                    });
                }
            }
            $(document).ready(function() {
                // 自動隱藏成功提示
                var successAlert = $('#successAlert');
                if (successAlert.length) {
                    setTimeout(function() {
                        successAlert.fadeOut('slow', function() {
                            $(this).alert('close');
                        });
                    }, 3000); // 3 秒後自動關閉
                }

                // 自動隱藏錯誤提示
                var errorAlert = $('#errorAlert');
                if (errorAlert.length) {
                    setTimeout(function() {
                        errorAlert.fadeOut('slow', function() {
                            $(this).alert('close');
                        });
                    }, 3000); // 3 秒後自動關閉
                }
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/task_flow/index.blade.php ENDPATH**/ ?>