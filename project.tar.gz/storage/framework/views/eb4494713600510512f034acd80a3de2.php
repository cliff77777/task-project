
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('layouts.sidebarMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <h1 class="my-4">工作單詳情</h1>
            <div class="mb-4">
                <h3></h3>
                <p></p>
                <p><strong>預計工時:</strong> 小時</p>
                <p><strong>創建人:</strong> </p>
                <p><strong>指派給:</strong> <?php echo e($task->assignee->name ?? '未指派'); ?></p>
            </div>

            <div class="mb-4">
                <h4>更新工作備註</h4>
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="note" class="form-label">工作備註</label>
                        <textarea class="form-control" id="note" name="note"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="actual_hours" class="form-label">實際工時</label>
                        <input type="number" step="0.1" class="form-control" id="actual_hours" name="actual_hours"
                            value="">
                    </div>
                    <button type="submit" class="btn btn-primary">更新</button>
                </form>
            </div>

            <div class="mb-4">
                <h4>上傳文件</h4>
                <form action="" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="file" class="form-label">選擇文件</label>
                        <input type="file" class="form-control" id="file" name="file" required>
                    </div>
                    <button type="submit" class="btn btn-primary">上傳</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/task/task_index.blade.php ENDPATH**/ ?>