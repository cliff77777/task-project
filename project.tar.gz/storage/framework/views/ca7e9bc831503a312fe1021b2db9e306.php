

<?php $__env->startSection('content'); ?>
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <h1 class="my-4">新增工作單</h1>
        <form action="<?php echo e(route('tasks.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3 col-md-3">
                <label for="subject" class="form-label">主旨</label>
                <input type="text" class="form-control" id="subject" name="subject">
            </div>
            <div class="mb-3 col-md-6">
                <label for="description" class="form-label">工作內容說明</label>
                <textarea class="form-control" id="description" name="description"></textarea>
            </div>
            <div class="mb-3 col-md-2">
                <label for="estimated_hours" class="form-label">預計工時/hr</label>
                <input type="number" step="0.1" class="form-control" id="estimated_hours" name="estimated_hours"
                    required>
            </div>
            <div class="mb-3 col-md-3">
                <label for="task_flow_template" class="form-label">工作流程</label>
                <select class="form-control" id="task_flow_template" name="task_flow_template_id"required>
                    <?php $__currentLoopData = $task_flow_template; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($template->id); ?>"><?php echo e($template->task_flow_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <h4>檔案上傳</h4>
            <div class="mb-3 col-md-3">
                <label for="file" class="form-label">選擇文件</label>
                <input type="file" class="form-control" id="file" name="file">
            </div>
            <button type="submit" class="btn btn-primary mb-3">提交</button>
        </form>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/tasks/create.blade.php ENDPATH**/ ?>