

<?php $__env->startSection('content'); ?>
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <h1 class="my-4">權限列表</h1>
        <div class="row">
            <div class="mb-3 col-md-2">
                <label for="user_role_name" class="form-label">權限名稱</label>
                <input type="text" class="form-control" value="<?php echo e($role->role_name); ?>" readonly>
            </div>
        </div>
        <div class="mb-3">
            <div id="formContainer">
                <div class="row align-items-center mb-3">
                    <div class="col-md-2">
                        <label for="user_role_descript" class="form-label">權限說明</label>
                        <input type="text" value="<?php echo e($role->role_descript); ?>" class='form-control' readonly>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <div id="formContainer">
                <div class="align-items-center mb-3">
                    <div class="col-md-2">
                        <label for="role_control" class="form-label">權限控制</label>
                        
                    </div>
                </div>
                <table class="table table-striped">
                    <tr>
                        <th>使用者名稱</th>
                        <th>權限</th>
                        <th>創建日期</th>
                    </tr>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->role); ?></td>
                            <td><?php echo e($user->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <div>
                    <?php if($users->onFirstPage()): ?>
                        <!-- 如果在第一頁，不顯示上一頁按鈕 -->
                    <?php else: ?>
                        <a href="<?php echo e($users->previousPageUrl()); ?>" class="btn btn-primary">上一頁</a>
                    <?php endif; ?>

                    <?php if($users->hasMorePages()): ?>
                        <a href="<?php echo e($users->nextPageUrl()); ?>" class="btn btn-primary">下一頁</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/user_role/show.blade.php ENDPATH**/ ?>