<?php
return [
    'welcome' => '歡迎來到我們的網站！',
    'about' => '關於我們',
    'contact' => '聯絡我們',
    'Register'=>'註冊',
    'Name'=>'姓名',
    'Phone'=>'手機電話',
    'E-Mail Address'=>'電子郵件',
    'Password'=>'密碼',
    'Confirm Password'=>'確認密碼',
    "Passwords do not match"=>"密碼不符合",
    "Email already exists."=>'信箱已註冊'
];

?>