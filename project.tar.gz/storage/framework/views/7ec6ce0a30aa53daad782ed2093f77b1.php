

<?php $__env->startSection('content'); ?>
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <h1 class="my-4">新增使用者</h1>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('user_manage.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="mb-3 col-md-2">
                    <label for="name" class="form-label">使用者名稱</label>
                    <input type="text" class="form-control" id="name" name="name" required
                        value="<?php echo e(old('name')); ?>">
                </div>
            </div>
            <div class="mb-3">
                <div class="row align-items-center mb-3">
                    <div class="col-md-2">
                        <label for="email" class="form-label">使用者信箱</label>
                        <input type="text" name="email" class='form-control'id="email" required
                            value="<?php echo e(old('email')); ?>">
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <div class="row align-items-center mb-3">
                    <div class="col-md-2">
                        <label for="password" class="form-label">密碼</label>
                        <input type="password" name="password" class='form-control'id="password" required
                            value="<?php echo e(old('password')); ?>">
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <div class="row align-items-center mb-3">
                    <div class="col-md-2">
                        <label for="password_confirmation" class="form-label">再次確認密碼</label>
                        <input type="text" name="password_confirmation" class='form-control'id="password_confirmation"
                            required value="<?php echo e(old('password_confirmation')); ?>">
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <h1 class="my-4"> 會員權限</h1>
                <div id="formContainer">
                    <?php $__currentLoopData = $user_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="role" id="role<?php echo e($role->id); ?>"
                                <?php echo e(old('role') == $role->id ? 'checked' : ''); ?> value='<?php echo e($role->id); ?>'>
                            <label class="form-check-label" for="role<?php echo e($role->id); ?>">
                                <?php echo e($role->role_name); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mb-3">提交</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/user_manage/create.blade.php ENDPATH**/ ?>