

<?php $__env->startSection('content'); ?>
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="container mt-5">
            <?php if(session('success')): ?>
                <div id="successAlert" class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div id="errorAlert" class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
        </div>

        <h1 class="my-4">權限列表</h1>
        <div class="mb-4">
            <a href="<?php echo e(route('user_role.create')); ?>" class="btn btn-primary">新增權限</a>
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>權限名稱</th>
                    <th>創建人</th>
                    <th>權限控制</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $user_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($role->role_name); ?></td>
                        <td><?php echo e($role->username->name); ?></td>
                        <td><?php echo e(json_encode($role->role_control)); ?></td>
                        <td>
                            <a href="<?php echo e(route('user_role.show', $role->id)); ?>" class="btn btn-sm btn-info">詳情</a>
                            
                            <a href="<?php echo e(route('user_role.edit', $role->id)); ?>" class="btn btn-sm btn-warning">權限編輯</a>
                            
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div>
            <?php if($user_role->onFirstPage()): ?>
                <!-- 如果在第一頁，不顯示上一頁按鈕 -->
            <?php else: ?>
                <a href="<?php echo e($user_role->previousPageUrl()); ?>" class="btn btn-primary">上一頁</a>
            <?php endif; ?>

            <?php if($user_role->hasMorePages()): ?>
                <a href="<?php echo e($user_role->nextPageUrl()); ?>" class="btn btn-primary">下一頁</a>
            <?php endif; ?>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                // 自動隱藏成功提示
                var successAlert = $('#successAlert');
                if (successAlert.length) {
                    setTimeout(function() {
                        successAlert.fadeOut('slow', function() {
                            $(this).alert('close');
                        });
                    }, 3000); // 3 秒後自動關閉
                }

                // 自動隱藏錯誤提示
                var errorAlert = $('#errorAlert');
                if (errorAlert.length) {
                    setTimeout(function() {
                        errorAlert.fadeOut('slow', function() {
                            $(this).alert('close');
                        });
                    }, 3000); // 3 秒後自動關閉
                }
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/user_role/index.blade.php ENDPATH**/ ?>