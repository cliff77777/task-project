
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Error Content')); ?></div>
                    <div class="card-body">
                        <div class="alert alert-danger" role="alert">
                            <div><?php echo e(session('error')); ?></div>
                            <?php if(session('error') == 'Your email is not verified.'): ?>
                                <?php echo e(__('If you did not receive the email')); ?>,
                                <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('click here to resend verity email')); ?>

                                    </button>.
                                </form>
                            <?php else: ?>
                                <?php echo e(__(session('error'))); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/error/error_index.blade.php ENDPATH**/ ?>