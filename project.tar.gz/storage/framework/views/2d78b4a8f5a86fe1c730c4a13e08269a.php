

<?php $__env->startSection('content'); ?>
    <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <h1 class="my-4">使用者編輯</h1>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('user_manage.update', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="mb-3 col-md-2">
                    <label for="name" class="form-label">使用者名稱</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
                </div>
            </div>
            <div class="mb-3">
                <div class="row align-items-center mb-3">
                    <div class="col-md-2">
                        <label for="role_descript" class="form-label">聯絡信箱</label>
                        <input type="text" name="role_descript" class='form-control' readonly
                            value="<?php echo e($user->email); ?>">
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <div class="row align-items-center mb-3">
                    <div class="col-md-2">
                        <label for="origin_password" class="form-label">原始密碼</label>
                        <input type="text" class='form-control' id='origin_password'>
                    </div>
                </div>
            </div>
            <span id="response_password_message"></span>
            <div class="mb-3">
                <div class="row align-items-center mb-3">
                    <div class="col-md-2">
                        <label for="password" class="form-label">修改密碼</label>
                        <input type="text" name="password" class='form-control' id="password"readonly>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <h1 class="my-4"> 會員權限</h1>
                <div id="formContainer">
                    <?php $__currentLoopData = $user_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="role" id="role<?php echo e($role->id); ?>"
                                value='<?php echo e($role->id); ?>'>
                            <label class="form-check-label" for="role<?php echo e($role->id); ?>">
                                <?php echo e($role->role_name); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mb-3">更新使用者</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.getElementById('origin_password').addEventListener('blur', function() {
            var origin_password = document.getElementById('origin_password').value;
            var password = document.getElementById('password');
            var origin_password_message = document.getElementById('response_password_message');
            $.ajax({
                url: '<?php echo e(route('password_check')); ?>',
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    'id': <?php echo e($user->id); ?>,
                    'origin_password': origin_password
                },
                success: function(response) {
                    origin_password_message.innerHTML = '<span class="text-success">' +
                        response.message + '</span>';
                    password.readOnly = false;;
                },
                error: function(xhr) {
                    // 錯誤時處理
                    var response = xhr.responseJSON;
                    if (response && response.message) {
                        origin_password_message.innerHTML = '<span class="text-danger">' + response
                            .message + '</span>';
                        password.readOnly = true;
                    } else {
                        origin_password_message.innerHTML = '<span class="text-danger">密碼驗證失敗</span>';
                        password.readOnly = true;
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/user_manage/edit.blade.php ENDPATH**/ ?>