

<?php $__env->startSection('content'); ?>
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $task)): ?>
        <div class="col-md-9 ms-sm-auto col-lg-10 px-md-4 mt-5">
            <h1>Edit Task</h1>
            <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group mb-3">
                    <label for="subject">Subject:</label>
                    <input type="text" class="form-control" id="subject" name="subject"
                        value="<?php echo e(old('subject', $task->subject)); ?>" required>
                </div>

                <div class="form-group mb-3">
                    <label for="description">Description:</label>
                    <textarea class="form-control" id="description" name="description" required><?php echo e(old('description', $task->description)); ?></textarea>
                </div>

                <div class="form-group mb-3">
                    <label for="estimated_hours">Estimated Hours:</label>
                    <input type="number" class="form-control" id="estimated_hours" name="estimated_hours"
                        value="<?php echo e(old('estimated_hours', $task->estimated_hours)); ?>" required>
                </div>

                <div class="form-group mb-3">
                    <label for="task_flow_template_id">任務流程</label>
                    <?php if(empty($task->task_flow_template)): ?>
                        <select class="form-control" id="task_flow_template_id" name="task_flow_template_id">
                            <option value="">---please select---</option>
                            <?php $__currentLoopData = $task_flow_template; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($template->id); ?>">

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <input type="text" class="form-control" readonly
                                value="<?php echo e($task->task_flow_template->task_flow_name); ?>">
                            <input type="text" class="form-control" readonly hidden
                                value="<?php echo e($task->task_flow_template->id); ?>" id="task_flow_template_id"
                                name="task_flow_template_id">
                    <?php endif; ?>

                    </select>
                </div>
                
                <div class="form-group mb-3">
                    <label for="assigned_to">分配給:</label>
                    <?php if(!empty($task->assigned_to)): ?>
                        <select class="form-control" id="assigned_to" name="assigned_to"
                            <?php echo e($check_task_step_status->status !== '0' ? 'success' : 'disabled'); ?>>
                            <option value="">---請先選擇任務流程---</option>
                            <?php $__currentLoopData = $assign_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user['id']); ?>"
                                    <?php echo e($task->task_flow_template_id == $user['id'] ? 'selected' : 'false'); ?>>
                                    <?php echo e($user['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php else: ?>
                        <select class="form-control" id="assigned_to" name="assigned_to">
                            <option value="">---請選擇---</option>
                            <?php $__currentLoopData = $assign_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user['id']); ?>"><?php echo e($user['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php endif; ?>

                </div>

                <?php if(!empty($task->files)): ?>
                    <h4>已上傳檔案</h4>
                    <?php $__currentLoopData = $task->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3">
                            <a
                                href="<?php echo e(Storage::url($file->file_path)); ?>"><?php echo e($file->file_name ? $file->file_name : 'unknow'); ?></a>
                            <?php echo e(formatSizeUnits(Storage::size('public/' . $file->file_path))); ?>


                            <a href="<?php echo e(route('download_file', ['file_path' => $file->file_path])); ?>" method='POST'
                                class="btn-sm btn-info text-white me-1">Download
                            </a>
                            <a href="#"
                                onclick="confirmDelete(event, '<?php echo e(route('delete_file', ['file_path' => $file->file_path])); ?>')"
                                class="btn-sm btn-danger">Delete
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <h4>檔案上傳</h4>
                <div class="mb-3">
                    <label for="file" class="form-label">選擇文件</label>
                    <input type="file" class="form-control" id="file" name="file">
                </div>
                <button type="submit" class="btn btn-primary">Update Task</button>
            </form>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        function confirmDelete(event, url) {
            event.preventDefault();
            var confirmAction = confirm("Are you sure you want to delete this item?");
            if (confirmAction) {
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: {
                        _method: 'DELETE',
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        alert('Item deleted successfully.');
                        location.reload()
                    },
                    error: function(xhr) {
                        alert('An error occurred while deleting the item.');
                    }
                });
            }
        }


        $('#task_flow_template_id').on('change', function() {
            var task_flow_template = $('#task_flow_template_id').val();
            var assigned_to = $('#assigned_to');
            assigned_to.empty();
            if (task_flow_template) {
                $.ajax({
                    url: '<?php echo e(route('get_task_assign')); ?>',
                    type: 'GET',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        'task_flow_template_id': task_flow_template,
                    },
                    success: function(response) {
                        // console.log(count(response));
                        assigned_to.prop('disabled', false); // 取消禁用select
                        if (response === null || response === undefined) {
                            assigned_to.empty();
                            assigned_to.append('<option value="">---沒有找到符合的用戶---</option>');
                            assigned_to.prop('disabled', true); // 禁用select
                        } else {
                            assigned_to.empty();
                            assigned_to.append('<option value="">---請選擇---</option>');
                            $.each(response.success, function(key, value) {
                                assigned_to.append('<option value="' + value.id + '">' + value
                                    .name +
                                    '</option>');
                            });
                        }
                    },
                    error: function(xhr) {
                        console.log('發生錯誤:', xhr);
                        // 處理錯誤情況
                        assign_error_msg.text('發生錯誤，請稍後再試。').attr('hidden', false);
                        assigned_to.prop('disabled', true); // 禁用select
                    }
                });
            } else {
                assigned_to.append('<option value="" >---請先選擇任務流程---</option>');
                assigned_to.prop('disabled', true);
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/tasks/edit.blade.php ENDPATH**/ ?>