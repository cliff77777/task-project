<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('tasks.index')); ?>">
                    Task Menu
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('tasks.create')); ?>">
                    Add Task Tickets
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('activity_log.index')); ?>">
                    Activity Log
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('task_flow.index')); ?>">
                    Task Flow
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user_manage.index')); ?>">
                    User Manage
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user_role.index')); ?>">
                    User Role
                </a>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH /var/www/html/resources/views/layouts/sidebarMenu.blade.php ENDPATH**/ ?>